//Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Windows.Navigation;

namespace Microsoft.WindowsAPICodePack.Samples.StarBackupSample
{
    public delegate void WizardReturnEventHandler(object sender, WizardReturnEventArgs e);
}
