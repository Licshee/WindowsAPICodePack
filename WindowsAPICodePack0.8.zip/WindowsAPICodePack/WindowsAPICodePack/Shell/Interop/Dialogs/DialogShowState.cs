//Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.WindowsAPICodePack.Shell
{
    internal enum DialogShowState
    {
        PreShow,
        Showing,
        Closing, 
        Closed
    }
}
