//Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Reflection;
using Microsoft.WindowsAPICodePack.Shell;
using System.IO;
using System.Diagnostics;

namespace Microsoft.WindowsAPICodePack.Shell
{
    /// <summary>
    /// Exposes methods that create known folders 
    /// and return the path for a specified known folder.
    /// </summary>
    internal static class KnownFolderManager
    {
        static IKnownFolderManager _knownFolderManager = (IKnownFolderManager)new KnownFolderManagerClass();

        /// <summary>
        /// Gets the known folder identified by the specified folder Id.
        /// </summary>
        /// <param name="knownFolderId">
        /// A Guid that identifies a known folder.
        /// </param>
        /// <returns>
        /// The known folder for the specified id.
        /// </returns>
        
        internal static KnownFolder GetKnownFolder(Guid knownFolderId)
        {
            IKnownFolder knownFolder;
            _knownFolderManager.GetFolder(knownFolderId, out knownFolder);

            return new KnownFolder(knownFolder);
        }
        
        /// <summary>
        /// Gets the known folder identified by its canonical name.
        /// </summary>
        /// <param name="canonicalName">
        /// A non-localized canonical name for the known folder.
        /// </param>
        /// <returns>
        /// A known folder representing the specified name.
        /// </returns>
        private static KnownFolder GetKnownFolder(string canonicalName)
        {
            IKnownFolder _knownFolder;
            _knownFolderManager.GetFolderByName(
                canonicalName, 
                out _knownFolder);

            return new KnownFolder(_knownFolder);
        }

        internal static KnownFolder GetKnownFolderFromPIDL(
            IntPtr pidl)
        {
            IKnownFolder _knownFolder;

            _knownFolderManager.FindFolderFromIDList(pidl, out _knownFolder);

            return new KnownFolder(_knownFolder);
        }

        /// <summary>
        /// Return a known folder from its Shell namespace Parsing name; 
        /// e.g. "::{645FF040-5081-101B-9F08-00AA002F954E}" for Recycle Bin
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static KnownFolder GetKnownFolderFromParsingName(
            string name)
        {
            IntPtr pidl = ShellHelper.PidlFromParsingName(name);

            if (pidl == IntPtr.Zero)
            {
                return null;
            }


            try
            {
                // It's probably a special folder, try to get it                
                return KnownFolderManager.GetKnownFolderFromPIDL(pidl);
            }
            catch (FileNotFoundException)
            {
                // No physical storage was found for this known folder
                // We'll try again with a different name
            }

            // try one more time with a training \0
            pidl = ShellHelper.PidlFromParsingName(name + "\\0");

            if (pidl == IntPtr.Zero)
            {
                return null;
            }

            return KnownFolderManager.GetKnownFolderFromPIDL(pidl);
        }

        internal static KnownFolder GetKnownFolder(
            string name, bool isCanonicalName)
        {
            if (isCanonicalName)
                return GetKnownFolder(name);

            // The name must matche a field name in FolderIdentifiers.
            // The field holds the GUID for the folder.
            // Use reflection to get the GUID.

            Type folderIDs = typeof(FolderIdentifiers);

            FieldInfo fp = folderIDs.GetField(name,
                BindingFlags.NonPublic | BindingFlags.Static);

            if (fp == null)
            {
                throw new ArgumentException("Known folder name is not valid.");
            }
            Guid id = (Guid)fp.GetValue(null);
            KnownFolder kf = GetKnownFolder(id);
            return kf;
        }
        /// <summary>
        /// Returns the path of a known folder
        /// </summary>
        internal static string GetPath(Guid knownFolderId)
        {
            IKnownFolder _knownFolder;
            _knownFolderManager.GetFolder(knownFolderId, out _knownFolder);

            FolderCategory category = _knownFolder.GetCategory();
            if (category == FolderCategory.Virtual)
            {
                return String.Empty;
            }
            return _knownFolder.GetPath(0);
        }
    }
}