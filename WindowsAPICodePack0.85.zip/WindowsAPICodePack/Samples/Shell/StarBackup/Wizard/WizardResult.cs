//Copyright (c) Microsoft Corporation.  All rights reserved.

using System;

namespace Microsoft.WindowsAPICodePack.Samples.StarBackupSample
{
    public enum WizardResult
    {
        Finished,
        Canceled
    }
}
