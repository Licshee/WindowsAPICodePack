// Copyright (c) Microsoft Corporation.  All rights reserved.

#include "StdAfx.h"
#include "DXGIException.h"
