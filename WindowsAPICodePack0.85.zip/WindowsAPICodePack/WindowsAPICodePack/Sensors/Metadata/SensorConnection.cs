﻿// Copyright (c) Microsoft Corporation.  All rights reserved.

namespace Microsoft.WindowsAPICodePack.Sensors
{
    /// <summary>
    /// 
    /// </summary>
    public enum SensorConnectionType
    {
        /// <summary>
        /// 
        /// </summary>
        Invalid = -1,
        /// <summary>
        /// 
        /// </summary>
        Intergrated = 0,
        /// <summary>
        /// 
        /// </summary>
        Attached = 1,
        /// <summary>
        /// 
        /// </summary>
        External = 2
    }
}
